package org.openhds.mobile;

import org.openhds.mobile.model.FieldWorker;

public interface FieldWorkerProvider {

    FieldWorker getFieldWorker();

}
