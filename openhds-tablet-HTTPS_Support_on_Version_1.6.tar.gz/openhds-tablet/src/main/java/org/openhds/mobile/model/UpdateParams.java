package org.openhds.mobile.model;

public class UpdateParams {

	public static final String HIERARCHY_TOP_LEVEL = "Country";
}
