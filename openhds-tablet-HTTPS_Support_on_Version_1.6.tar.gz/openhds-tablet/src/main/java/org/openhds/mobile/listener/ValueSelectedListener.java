package org.openhds.mobile.listener;

public interface ValueSelectedListener {
	
	public void onValueSelected(int position);

}
