package org.openhds.mobile.listener;

import org.openhds.mobile.model.Result;

public interface RetrieveFieldWorkersListener {
	
	public void retrieveFieldWorkersComplete(Result result);

}
